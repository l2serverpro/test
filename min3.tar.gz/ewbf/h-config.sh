#!/usr/bin/env bash

# Not required
function miner_fork() {
	local MINER_FORK=$EWBF_FORK
	[[ -z $MINER_FORK ]] && MINER_FORK=$MINER_DEFAULT_FORK

	#can be removed later, backward compat
	if [[ $MINER_FORK == "zhash_0.4" ]]; then
		MINER_FORK="zhash"
	fi

	echo $MINER_FORK
}


function miner_ver() {
	[[ -z $MINER_FORK ]] && MINER_FORK=`miner_fork`
	local MINER_VER=$EWBF_VER
	[[ -z $MINER_VER ]] && eval "MINER_VER=\$MINER_LATEST_VER_${MINER_FORK^^}" #uppercase MINER_FORK
	echo $MINER_VER
}


function miner_config_echo() {
	export MINER_FORK=`miner_fork`
	local MINER_VER=`miner_ver`
	miner_echo_config_file "/hive/miners/$MINER_NAME/dynex.conf"
}


function miner_config_gen() {
	local MINER_CONFIG="$MINER_DIR/dynex.conf"

[[ -z $ZPORT && $ZSERVER =~ (.*):([0-9]+) ]] && ZSERVER=${BASH_REMATCH[1]} && ZPORT=${BASH_REMATCH[2]}

conf=""
conf+="WAL=\"$ZTEMPLATE\""$'\n'
conf+="HOST=\"$ZSERVER\""$'\n'
conf+="PORT=\"$ZPORT\""$'\n'
conf+="PASS=\"$ZPASS\""$'\n'
conf+="EXTRA=\"$EWBF_USER_CONFIG\""$'\n'

echo "$conf" > $MINER_CONFIG

}
