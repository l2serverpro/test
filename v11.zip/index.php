<?php
ini_set('max_execution_time', 300);	
$GLOBALS['countnode']=0;

if (isset($_GET['key']))
{
$content = $_GET['key']; // Здесь ваше содержимое файла
$filename = time() . '.key'; // Имя файла как текущее время Unix и расширение .key

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="'.$filename.'"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . strlen($content));

echo $content;
die;
}

function removePrefixAndSuffix($string, $prefix) {
    $string = str_replace($prefix, '', $string);
    $string = str_replace('.key', '', $string);
    return $string;
}

function removekey($string) {
    $string = str_replace('.key', '', $string);
    return $string;
}



//error_reporting(E_ALL & ~E_WARNING);
$starthtml = '
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Stereo V11 Spacemesh node check</title>
<link rel="stylesheet" href="default.css">
<script>
  function toggleTable(id) {
    var lTable = document.getElementById("table_" + id);
    var lLink = document.getElementById("hide_table_" + id);
    
    // Инвертируем состояние видимости таблицы
    lTable.style.display = (lTable.style.display === "table" ? "none" : "table");
    
    // Инвертируем текст ссылки
    lLink.innerHTML = (lLink.innerHTML === "+" ? "-" : "+");
  }
</script>
<script src="/table-sort.min.js"></script>
<link rel=icon type=image/png href=/ico.png>
</head>
<body>
';	

$stophtml = '
</body>
</html>
';



echo $starthtml;



function addPostNode($newLine) {
	$filename = "conf.php";
    // Читаем содержимое файла в массив строк
    $lines = file($filename);
    // Вставляем новую строку на вторую позицию (индекс 1)
    array_splice($lines, 1, 0, $newLine . "\n");
    // Сохраняем измененный массив обратно в файл
    file_put_contents($filename, implode("", $lines));
}


if (isset($_POST['noderestart']))
{
			$status = trimControlCharsAndSpaces(linuxcom('systemctl is-active '.$_POST['noderestart'],1));
			echo "<p>Статус службы: $status ";
			
			if ($status == 'active')
			{	
				$ser = pasreservice(linuxcom('systemctl show -p ExecStart -p ActiveEnterTimestamp '.$_POST['noderestart'],1));
				
				echo "cлужба запущена: ".$ser['activeEnterTimestamp'].", каталог DATA: ".$ser['d']."<br>";
				
				if ($ser['d']  !== 'Parameter -d not found' && $ser['activeEnterTimestamp'] !== 'ActiveEnterTimestamp not found')
				{
					echo "похоже можем перезапустить<br>";
					//linuxcom('sudo systemctl restart '.$_POST['noderestart'],0);
				}
				
				
			}
			echo "</p></br></br>";
	echo $stophtml;
	die;
}

if (isset($_POST['poststart']))
{

	$keys = explode(" ", $_POST['poststart']);
	foreach ($keys as $key) {
			$status = trimControlCharsAndSpaces(linuxcom('systemctl is-active '.$key,1));
			echo "<p>Статус службы: $status ";
			
			if ($status == 'inactive' or $status == 'failed')
			{	
				$ser = pasreservicepost(linuxcom('systemctl show -p ExecStart -p ActiveEnterTimestamp '.$key,1));
				
				echo "cлужба остановлена: ".$ser['activeEnterTimestamp'].", каталог DATA: ".$ser['dir']."<br>";
				
				if ($ser['dir']  !== 'Parameter -dir not found' && $ser['activeEnterTimestamp'] !== 'ActiveEnterTimestamp not found')
				{
					echo "Запускаем службу $key<br>";
					linuxcom('sudo systemctl start '.$key,0);
				}
				
				
			}
	}
			echo "</p></br></br>";
	echo $stophtml;
	die;
}

if (isset($_POST['poststop']))
{
$keys = explode(" ", $_POST['poststop']);
// Обход массива и обработка каждого элемента
foreach ($keys as $key) {
			$status = trimControlCharsAndSpaces(linuxcom('systemctl is-active '.$key,1));
			echo "<p>Статус службы: $status ";
			if ($status == 'active')
			{	
				$ser = pasreservicepost(linuxcom('systemctl show -p ExecStart -p ActiveEnterTimestamp '.$key,1));
				echo "cлужба запущена: ".$ser['activeEnterTimestamp'].", каталог DATA: ".$ser['dir']."<br>";
				if ($ser['dir']  !== 'Parameter -dir not found' && $ser['activeEnterTimestamp'] !== 'ActiveEnterTimestamp not found')
				{
					echo "Останавливаем службу $key<br>";
					linuxcom('sudo systemctl stop '.$key,0);
				}
			}
			else
			{
				echo "Служба $key не запущена.</br>";
			}
			echo "</p></br></br>";

}
	echo $stophtml;
	die;

}

if (isset($_POST['nodestop']))
{
			$status = trimControlCharsAndSpaces(linuxcom('systemctl is-active '.$_POST['nodestop'],1));
			echo "<p>Статус службы: $status ";
			
			if ($status == 'active')
			{	
				$ser = pasreservice(linuxcom('systemctl show -p ExecStart -p ActiveEnterTimestamp '.$_POST['nodestop'],1));
				
				echo "cлужба остановлена: ".$ser['activeEnterTimestamp'].", каталог DATA: ".$ser['d']."<br>";
				
				if ($ser['d']  !== 'Parameter -d not found' && $ser['activeEnterTimestamp'] !== 'ActiveEnterTimestamp not found')
				{
					echo "похоже можем остановить ноду<br>";
					linuxcom('sudo systemctl stop '.$_POST['nodestop'],0);
				}
			}
			echo "</p></br></br>";
	echo $stophtml;
	die;
}
//Обработка добавления нового ключа
if (isset($_POST['fileContent']))
{
//	print_r($_POST);
	if (strlen($_POST['fileContent']) == 128)
	{
		$ser = trimControlCharsAndSpaces(linuxcom('[ -d "'.$_POST['path'].'/identities" ] && echo 1 || echo 0',1));

		if ($ser == 1)
		{
			echo "<p>Папка найдена</p>";
			$ser = trimControlCharsAndSpaces(linuxcom('[ -f "'.$_POST['path'].'/identities/'.$_POST['fileName'].'" ] && echo 1 || echo 0',1));
			if ($ser == 1)
			{
				echo "<p>Такой файл уже есть".$_POST['path'].'/identities/'.$_POST['fileName']."</p>";
				echo $stophtml;
				die;
			}
			else
			{
				echo "<p>Файла нет ".$_POST['path'].'/identities/'.$_POST['fileName']."</p>";
				linuxcom('echo -n "'.$_POST['fileContent'].'" > '.$_POST['path'].'/identities/'.$_POST['fileName'],0);
				$ser = trimControlCharsAndSpaces(linuxcom('[ -f "'.$_POST['path'].'/identities/'.$_POST['fileName'].'" ] && echo 1 || echo 0'),1);
				if ($ser == 1)
				{
					echo "<p>Файл успешно записан</p>";
					echo $stophtml;
					die;
				}
				else
				{
					echo "<p>Файл не записан</p>";
					echo $stophtml;
					die;				
				}
			}
			
		}
		else
		{	
			echo "<p>Папка".$_POST['path']."/identities не найдена</p>";
			echo $stophtml;
			die;
		}
	}
	else
	{
		echo "<p>Размер файла 128 байт должен быть</p>";
		echo $stophtml;
		die;
	}
	
	
}




if (isset($_POST['nodestart']))
{
			$status = trimControlCharsAndSpaces(linuxcom('systemctl is-active '.$_POST['nodestart'],1));
			echo "<p>Статус службы: $status ";
			
			if ($status == 'inactive' or $status == 'failed')
			{	
				$ser = pasreservice(linuxcom('systemctl show -p ExecStart -p ActiveEnterTimestamp '.$_POST['nodestart'],1));
				
				echo "cлужба запущена: ".$ser['activeEnterTimestamp'].", каталог DATA: ".$ser['d']."<br>";
				
				if ($ser['d']  !== 'Parameter -d not found' && $ser['activeEnterTimestamp'] !== 'ActiveEnterTimestamp not found')
				{
					echo "Отправляем команду на запуск.<br>";
					linuxcom('sudo systemctl start '.$_POST['nodestart'],0);
				}
				
				
			}
			echo "</p></br></br>";
	echo $stophtml;
	die;
}



if (isset($_POST['keygen']))
{
			if (!extension_loaded('sodium')) {
			    echo '<p>Предупреждение: расширение sodium не включено в вашей конфигурации PHP. откройте php.ini и раскоментируйте extension=sodium</p>';
			    echo '<p>Используемый файл конфигурации PHP: ' . php_ini_loaded_file().'</p>';
				echo $stophtml;
				die;
			} 
			$privateKey = sodium_crypto_box_keypair();
			$publicKey = sodium_crypto_box_publickey($privateKey);
			echo "<p>Key: " . bin2hex($privateKey) . "</p>";
			$status = grpcurl($_POST['ip'].":".$_POST['port'],6);
			$atx = bin2hex(base64_decode($status["1"]["atx"]["id"]["id"]));
			//print_r($status);
			echo "<p>ATX: $atx ";
			echo "<p>NodeID: ".bin2hex($publicKey)."</p>";
			echo "</p>
			<p>
			<form action=\"/index.php\" method=\"get\" target=\"_blank\">
					  <input type=\"hidden\" name=\"key\" value=\"".bin2hex($privateKey)."\">
					  <input type=\"submit\" value=\"Сохранить файл key\">
					</form>
			</p>
			
			
			<br><br>";
	echo $stophtml;
	die;
}

function convertToHtml($text) {
    // Замена символов переноса строки \r на HTML тег <br>
    return str_replace("\n", "<br>", $text);
}

if (isset($_POST['nodelog']))
{
			$status = trimControlCharsAndSpaces(linuxcom('systemctl is-active '.$_POST['nodelog'],1));
			echo "<p>Статус службы: $status ";
			if ($status == 'inactive' or $status == 'failed' or $status == 'active')
			{	
				echo '<p class="plog">';
				$ser = convertToHtml(linuxcom('journalctl -u '.$_POST['nodelog'].' -r -n 100',1));
				
				echo "$ser<br></p>";
				
			}
			echo "</p></br></br>";
	echo $stophtml;
	die;
}

function trimControlCharsAndSpaces($str) {
    // Удаляем управляющие символы и пробелы спереди и сзади строки
    $trimmed = trim($str, " \t\n\r\0\x0B");
    return $trimmed;
}

function ensureTrailingSlash($path) {
    if (substr($path, -1) !== '/') {
        $path .= '/';
    }
    return $path;
}

if (isset($_POST['addpost']))
{
			if (is_numeric(getPortFromIPAndPort($_POST['addpost'],0)) and is_numeric($_POST['grpcpostlistener']))
			{
			$_POST['dir'] = ensureTrailingSlash($_POST['dir']);
			$addpost=getPortFromIPAndPort($_POST['addpost'],0);
			$idnode=getPortFromIPAndPort($_POST['addpost'],1);
			echo "<p>Так, пытаемся добавить ".$_POST['perefixpost'].$addpost." службу для ключика. На адрес ноды: ".$_POST['IP'].":".$_POST['grpcpostlistener']."</p>";
			echo "<p>Ищем есть ли уже служба по адресу: ".$_POST['dirservice'].$_POST['perefixpost'].$addpost.'.service</p>';
			$status = trimControlCharsAndSpaces(linuxcom('if [ -f '.$_POST['dirservice'].$_POST['perefixpost'].$addpost.'.service ]; then echo 1; else echo 0; fi',1));
			if ($status == 1)
			{
				echo "<p>Файл уже существует запрашиваем информацию о службе</p>";
				$ser = pasreservicepost(linuxcom('systemctl show -p ExecStart -p ActiveEnterTimestamp '.$_POST['perefixpost'].$addpost,1));
				echo "<p>Настроки текущего сервиса:</p><p>Path: ".$ser['path']."</p><p>--address: ".$ser['address']."</p><p>--dir: ".$ser['dir']."</p>";
				echo "<p>Переданная конфигурация:</p><p>Path: ".$_POST['path'].'service'."</p><p>--address: http://".$_POST['IP'].":".$_POST['grpcpostlistener']."</p><p>--dir: ".$_POST['dir']."</p>";
				
				$status2 = trimControlCharsAndSpaces(linuxcom('if [ -f '.$_POST['dir'].'/postdata_metadata.json ]; then echo 1; else echo 0; fi',1));
				
				if ($status2 == 1)
				{
					$ser2 = linuxcom("cat ".$_POST['dir']."/postdata_metadata.json | jq -r '.NodeId'",1);
					$ser2 = trimControlCharsAndSpaces($ser2);
					echo "<p>Сверяем ID переданной ноды ".$idnode." и postdata_metadata.json в папке ".$ser2." </p>";
					if ($idnode == $ser2)
					{
						echo '<p>Мы можем начать обновление службы</p>';
						if ($_POST['yes'] == '1')
						{
							$com1 = 'sudo sed -i \'s|--address=http://'.$ser['address'].'|--address=http://'.$_POST['IP'].":".$_POST['grpcpostlistener'].'|g\' '.$_POST['dirservice'].$_POST['perefixpost'].$addpost.'.service';
							$com2 = 'sudo sed -i \'s|--dir='.$ser['dir'].'|--dir='.$_POST['dir'].'|g\' '.$_POST['dirservice'].$_POST['perefixpost'].$addpost.'.service';	
							linuxcom('sudo systemctl stop '.$_POST['perefixpost'].$addpost.'.service',1);	
							linuxcom($com1,0);
							linuxcom($com2,0);
							linuxcom('sudo systemctl daemon-reload');
							sleep(2);
							linuxcom('sudo systemctl start '.$_POST['perefixpost'].$addpost.'.service',1);
									
						}
							else
						{
								echo '<form action="/index.php" method="post"><input type="hidden" name="yes" value="1"><input type="hidden" name="addpost" value="'.$addpost.":".$idnode.'"><input type="hidden" name="dir" value="'.$_POST['dir'].'"><input type="hidden" name="grpcpostlistener" value="'.$_POST['grpcpostlistener'].'"><input type="hidden" name="perefixpost" value="'.$_POST['perefixpost'].'"><input type="hidden" name="IP" value="'.$_POST['IP'].'"><input type="hidden" name="dirservice" value="'.$_POST['dirservice'].'"><input type="hidden" name="user" value="'.$_POST['user'].'"><input type="hidden" name="path" value="'.$_POST['path'].'"><input type="submit" value="Все верно обновим службу"></form>';
						}
					}
					else
					{
						echo "<p>Плот в папке от другой ноды</p>";
					}
				}
				else
				{
					echo "<p>Файл postdata_metadata.json не найден в папке".$_POST['dir'].' мы не можем начать обновление службы</p>';
				}
				
				
			}
			else
			{
				echo "<p>Такой службы нет.</p>";
				$status2 = trimControlCharsAndSpaces(linuxcom('if [ -f '.$_POST['dir'].'/postdata_metadata.json ]; then echo 1; else echo 0; fi',1));
				
				if ($status2 == 1)
				{
					$ser2 = trimControlCharsAndSpaces(linuxcom("cat ".$_POST['dir']."/postdata_metadata.json | jq -r '.NodeId'",1));
					echo "<p>Сверяем ID переданной ноды ".$idnode." и postdata_metadata.json в папке ".$ser2." </p>";
					if ($idnode == $ser2)
					{
						$su = trimControlCharsAndSpaces(linuxcom("cat ".$_POST['dir']."/postdata_metadata.json | jq -r '.NumUnits'",1));
						if (!is_numeric($su))
						{
							echo "<p>В файле postdata_metadata не найден NumUnits ответ: $su</p>";
						}
//						$comand = 'ls -1 '.$_POST['dirservice'].' | grep '.$_POST['perefixpost'].'*[0-9] | sort -V | tail -n 1';
						//$comand = 'ls -1 '.$_POST['dirservice'].' | grep \'^'.$GLOBALS['perefixpost'].'[0-9]\+\.service$\' | sed -r \'s/'.$GLOBALS['perefixpost'].'([0-9]+)\.service/\1/\' | sort -n | tail -n 1';
						$comand = 'ls -1 '.$_POST['dirservice'].' | grep \''.$_POST['perefixpost'].'p*[0-9]\' | sort -V | tail -n 1';
						//echo "$comand<br>";
						$status3 = trimControlCharsAndSpaces(linuxcom($comand,0));
						//echo "ответ: $status3<br>";
						if ($status3 != '')
						{
							echo "<p>Запрашиваем порт последней службы $status3</p>";
							$comand ='systemctl show -p ExecStart -p ActiveEnterTimestamp '.$status3;
							$ser = linuxcom($comand,1);
							$ser = pasreservicepost($ser);
							if (is_numeric($ser['operator']))
							{

								$pp = $ser['operator']+1;
								echo "<p>Порт последней службы ".$ser['operator']." новый порт: ".$pp."</p>";
							}
							else
							{
								echo '<p>Не удалось запросить порт из службы. '.$status3.' ошибка</p>';
								echo $stophtml;
								die;
							}
						}
						else
						{
							echo '<p>Мы не нашли прошлый сервис в папке '.$_POST['dirservice'].' назначаем порт 50051</p>';
							$pp = '50051';
						}	
						
						
						
						echo "<p>Проверяем занят ли порт $pp</p>";

						// Функция для проверки порта
						function isPortBusy($port) {
						    $command = "ss -tuln | grep ':$port ' >/dev/null && echo 1 || echo 0";
						    //echo "$command<br>";
						    $status = trimControlCharsAndSpaces(linuxcom($command,1));
						    return $status === '1'; // Возвращает true, если порт занят
						}

						$attempts = 0;
						while ($attempts < 6) {
						    if (!isPortBusy($pp)) {
						        echo "<p>Порт $pp свободен.</p>";
						        break;
						    } else {
						        echo "<p>Порт $pp занят. Ошибка.</p>";
						        if ($attempts == 5) {
						            echo $stophtml;
						            die;
						        }
						        $pp++; // Прибавляем 1 к номеру порта и пытаемся снова
						        $attempts++;
						        echo "<p>Попытка номер " . ($attempts + 1) . " с портом $pp.</p>";
						    }
						}

						if ($attempts >= 6) {
						    echo "<p>Не удалось найти свободный порт после 5 попыток.</p>";
						    echo $stophtml;
						    die;
						}

						echo '<p>Мы можем начать создание службы</p>';		
						$text = '[Unit]
Description='.$_POST['perefixpost'].$addpost.'
[Service]
User='.$_POST['user'].'
WorkingDirectory='.$_POST['path'].'
ExecStart='.$_POST['path'].'service --address=http://'.$_POST['IP'].":".$_POST['grpcpostlistener'].' --dir='.$_POST['dir'].' --operator-address='.$_POST['IP'].':'.$pp.' --threads=144 --nonces=288 --randomx-mode=fast
Restart=always
[Install]
WantedBy=multi-user.target';	
									echo "<p>Создаем файл службы</p>";
									//echo "<p>$text</p>";
									linuxcom('echo -n "'.$text.'" | sudo tee '.$_POST['dirservice'].$_POST['perefixpost'].$addpost.'.service',1);
									linuxcom('sudo systemctl daemon-reload',0);		
									linuxcom('sudo systemctl start '.$_POST['perefixpost'].$addpost,0);
									$command = 'df -P "'.$_POST['dir'].'" | awk \'NR==2 {print $1}\'';
									//echo "$command <br>";
									$dv = trimControlCharsAndSpaces(linuxcom($command,1));
									//echo "$dv <br>";		
									$command = 'ls -l /dev/disk/by-uuid | grep "$(basename '.$dv.')" | awk \'{print $9}\'';	
									//echo "$command <br>";
									$uuid = trimControlCharsAndSpaces(linuxcom($command,1));												
									//echo "$uuid <br>";								
									echo "Добавляем в конфиг:<br>";
									echo 'addOrUpdatePostNode("'.$addpost.'.key","'.$_POST['IP'].':'.$pp.'","'.$su.'","/dev/disk/by-uuid/'.$uuid.'");';
									addPostNode('addOrUpdatePostNode("'.$addpost.'.key","'.$_POST['IP'].':'.$pp.'","'.$su.'","/dev/disk/by-uuid/'.$uuid.'");');
									echo $stophtml;
									die;											
								
					}
					else
					{
						echo '<p>Не равно.</>';
						echo $stophtml;	
						die;
					}
				}
				else
				{
					echo "<p>Файл postdata_metadata.json не найден в папке".$_POST['dir'].' мы не можем начать добавление службы</p>';
				}				
				
			}
			
			
			}
			else
			{
				echo "Ошибка номер ноды: ".getPortFromIPAndPort($_POST['addpost'],0)." или номер порта ".$_POST['grpcpostlistener']." не цифровое значение.";
			}
	echo $stophtml;
	die;
}

include('conf.php');

if (isset($GLOBALS['alllayer'])) {
	$allsu = 0;
	$ii = 0;
    // Если массив существует и это массив, перебираем его элементы
    echo '<a class="plus" id="hide_table_9999" onclick="toggleTable(9999);" href="#">+</a>ALL LAYER';
usort($GLOBALS['alllayer'], function($a, $b) {

    return $a['layer'] <=> $b['layer'];
});
	echo '<table class="table-sort" id="table_9999" style="display: none;"><tr><th>Main</th><th>Node</th><th>SU</th><th>Key</th><th>Layer</th><th>Date Layer</th></tr>';
    for ($i = 0; $i < count($GLOBALS['alllayer']); $i++) {
        $allsu = $allsu + $GLOBALS['alllayer'][$i]['su'];
        $ii++;
        echo '<tr><td><span style="color: '.$GLOBALS['alllayer'][$i]['color'].'">'.$GLOBALS['alllayer'][$i]['main'].'</span></td><td>'.$GLOBALS['alllayer'][$i]['ids']."</td><td>".$GLOBALS['alllayer'][$i]['su']."</td><td>".$GLOBALS['alllayer'][$i]['name']."</td><td>".$GLOBALS['alllayer'][$i]['layer']."</td><td>".$GLOBALS['alllayer'][$i]['dt']."</td></tr>";
    }
    echo "</table>";
    echo "<p>Ваша мощь в эпохе $allsu SU или ".round($allsu*64,2)." GB в $ii слоях</p>";
}

echo $stophtml;
	
function getPortFromIPAndPort($string,$i=1) {
    $parts = explode(':', $string);
    return $parts[$i];
}

function addOrUpdatePostNode($key, $ip, $su, $diskplot='') {
    global $postnode; // Объявляем массив как глобальный
	
    // Проверяем наличие записи с таким ключом
    if (isset($postnode[$key])) {
        // Заменяем IP и ID, если запись найдена
        $postnode[$key]['ip'] = $ip;
        $postnode[$key]['su'] = $su;
        $postnode[$key]['diskplot'] = $diskplot;
    } else {
        // Если запись не найдена, добавляем новую запись в массив postnode
        $postnode[$key] = array(
            'ip' => $ip,
            'su' => $su,
            'diskplot' => $diskplot
        );
    }
}

function addlayer($l) {
    global $alllayer; // Объявляем массив как глобальный
    
    if (!isset($alllayer)) {
    // Если массив не существует, создаем его
    $alllayer = [];
}
   
	$alllayer[] = $l;
}


function checkgrpcurl()
{
	$error_check = '';
	if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
	    exec('grpcurl --help', $output, $error_check);
	    $GLOBALS['os']=1;
	} else {
	    exec('which grpcurl', $output, $error_check);
	    $GLOBALS['os']=2;
	}
	if ($error_check !== 0) {
	    echo "Error: grpcurl not found. Make sure it is installed and available on your system. On Linux copy grpcurl to /usr/bin";
	    die();
	}
}

function parsing($output)
{
		 	preg_match_all('/\{(?:[^{}]|(?R))*\}/', $output, $matches);
			$i=1;
			foreach ($matches[0] as $json) {
			    $jsonObject = json_decode("{$json}", true);

			    if ($jsonObject === null && json_last_error() !== JSON_ERROR_NONE) {
			        echo "Ошибка при парсинге JSON: " . json_last_error_msg() . PHP_EOL;
			    } else {
			        $mass[$i]=$jsonObject;
					$i++;
			    }
			}
		    return $mass;
}

function grpcurl($IP,$COMMAD)
{

if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    $nl = ' 2> nul';
} else {
     $nl = ' 2>/dev/null';
}

		if ($COMMAD == 1) { $textcommand = 'spacemesh.v1.PostInfoService.PostStates'; $maxt = '5'; }
		if ($COMMAD == 2) { $textcommand = 'spacemesh.v1.AdminService.EventsStream'.$nl; $maxt = '5'; }
		if ($COMMAD == 3) { $textcommand = 'spacemesh.v1.NodeService.Status'; $maxt = '5'; }
		if ($COMMAD == 4) { $textcommand = 'spacemesh.v1.MeshService.CurrentEpoch'; $maxt = '5'; }
		if ($COMMAD == 5) { $textcommand = 'spacemesh.v1.NodeService.Version'; $maxt = '5'; }
		if ($COMMAD == 6) { $textcommand = 'spacemesh.v1.ActivationService.Highest'; $maxt = '250';  }
		
	$cmd = 'grpcurl -plaintext -d "{}" -max-time '.$maxt.' '.$IP.' '.$textcommand;
	//echo $cmd;
	$descriptorspec = array(
	    0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
	    1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
	    2 => array("pipe", "w")   // stderr is a pipe that the child will write to
	);
//	if ($COMMAD == 2) 	{ return parsing(file_get_contents('1.json'));	}
//	if ($COMMAD == 1)	{ return parsing(file_get_contents('2.json'));	}

		$process = proc_open($cmd, $descriptorspec, $pipes, realpath('./'), null);

		if (is_resource($process)) {
		    $output = stream_get_contents($pipes[1]);
		    fclose($pipes[1]);

			if ($output == '') 
			{
				echo "Your $IP did not respond to the request $textcommand<br>";
				return "";
			}
			
			if (strpos($output, "Failed to dial target host") !== false) {
				echo "$output<br>";
				return "";
			}			
			
	 		return parsing($output);
		} else {
		    echo "Error executing grpcurl.";
		    return "";
	
	}
}

function linuxcom($COMMAD,$err=1)
{
	$descriptorspec = array(
	    0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
	    1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
	    2 => array("pipe", "w")   // stderr is a pipe that the child will write to
	);
//	if ($COMMAD == 2) 	{ return parsing(file_get_contents('1.json'));	}
//	if ($COMMAD == 1)	{ return parsing(file_get_contents('2.json'));	}

		$process = proc_open($COMMAD.' 2>/dev/null', $descriptorspec, $pipes, realpath('./'), null);
		if (is_resource($process)) {
		    $output = stream_get_contents($pipes[1]);
		    fclose($pipes[1]);

			if ($output == '') 
			{
				if ($err == 1) { echo "Linux $COMMAD error<br>"; }
				return "";
			}
			
	 		return $output;
		} else {
		    echo "Error executing linux command." ;
		    return "";
	
	}
}

function wincom($IP,$disk)
{

	$descriptorspec = array(
	    0 => array("pipe", "r"),  // stdin is a pipe that the child will read from
	    1 => array("pipe", "w"),  // stdout is a pipe that the child will write to
	    2 => array("pipe", "w")   // stderr is a pipe that the child will write to
	);
		$COMMAD = 'powershell.exe -Command "Get-WmiObject -ComputerName \"'.$IP.'\" -Query \"SELECT DiskReadBytesPersec FROM Win32_PerfFormattedData_PerfDisk_PhysicalDisk WHERE Name LIKE \'%'.$disk.'\'\" | Select-Object -ExpandProperty DiskReadBytesPersec"';
		//echo "$COMMAD<br>";
		$process = proc_open($COMMAD, $descriptorspec, $pipes, realpath('./'), null);

		if (is_resource($process)) {
		    $output = stream_get_contents($pipes[1]);
		    fclose($pipes[1]);

			if ($output == '') 
			{
				echo "Windows error<br>";
				return "";
			}

			if (!is_numeric($output)) 
			{
				echo "Windows error2<br>";
				return "";
			}			
			
			
	 		return $output;
		} else {
		    echo "Error executing Windows command.";
		    return "";
	
	}
}


function searchForId($id, $array) {
   foreach ($array as $key => $val) {
       if ($val['id'] === $id) {
           return $key;
       }
   }
   return null;
}

function ct($arr) {
foreach ($arr as $key => $val) {
	echo $val . '<br>';
}
}


function saveArrayToJsonFile($nodeName, $epoch, $data) {
    $filePath = 'log.json'; // Путь к вашему файлу JSON
    $jsonArray = file_exists($filePath) ? json_decode(file_get_contents($filePath), true) : [];

    // Проверка и инициализация структуры
    if (!isset($jsonArray[$nodeName])) {
        $jsonArray[$nodeName] = [];
    }
    if (!isset($jsonArray[$nodeName][$epoch])) {
        $jsonArray[$nodeName][$epoch] = [];
    }

    // Слияние с учетом числовых ключей
    foreach ($data as $layer => $values) {
        if (!isset($jsonArray[$nodeName][$epoch][$layer])) {
            $jsonArray[$nodeName][$epoch][$layer] = [];
        }
        $jsonArray[$nodeName][$epoch][$layer] = array_replace_recursive($jsonArray[$nodeName][$epoch][$layer], $values);
    }

    // Запись обратно в файл
    file_put_contents($filePath, json_encode($jsonArray, JSON_PRETTY_PRINT));
}


function pasreservice($text)
{
			
		if (preg_match('/-d\s+([^ ]+)/', $text, $matches)) {
		    $s['d'] = $matches[1];
		} else {
		    $s['d'] = "Parameter -d not found";
		}
		
		if (preg_match('/--grpc-post-listener\s+([^ ]+)/', $text, $matches)) {
		    $s['grpcpostlistener'] = $matches[1];
		} else {
		    $s['grpcpostlistener'] = "Parameter --grpc-post-listener not found";
		}
		
		if (preg_match('/ActiveEnterTimestamp=(.*)/', $text, $matches)) {
		    $s['activeEnterTimestamp'] = $matches[1];
		} else {
		    $s['activeEnterTimestamp'] = "ActiveEnterTimestamp not found";
		}
		
		if (preg_match('/path=([^\s]+)/', $text, $matches)) {
		    $s['path'] = $matches[1];
		} else {
		    $s['path'] = "Parameter path not found";
		}
		return $s;
}

function pasreservicepost($text)
{
		if (preg_match('/--address=([^\s]+)/', $text, $matches)) {
		    $s['address'] = $matches[1];
		} else {
		    $s['address'] = "Parameter --address not found";
		}
		
		if (preg_match('/--dir=([^\s]+)/', $text, $matches)) {
		    $s['dir'] = $matches[1];
		} else {
		    $s['dir'] = "Parameter --dir not found";
		}
		if (preg_match('/path=([^\s]+)/', $text, $matches)) {
		    $s['path'] = $matches[1];
		} else {
		    $s['path'] = "Parameter path not found";
		}
		if (preg_match('/--operator-address=([^\s]+)/', $text, $matches)) {
		    $s['operator'] = getPortFromIPAndPort($matches[1]);
		} else {
		    $s['operator'] = "Parameter operator not found";
		}	
		
		if (preg_match('/ActiveEnterTimestamp=(.*)/', $text, $matches)) {
		    $s['activeEnterTimestamp'] = $matches[1];
		} else {
		    $s['activeEnterTimestamp'] = "ActiveEnterTimestamp not found";
		}	
		
		return $s;
}



function checkDevPath($text) {
    // Используем strpos для поиска подстроки /dev/
    if (strpos($text, '/dev/') !== false) {
        return 1;
    } else {
        return 0;
    }
}

function fetchData($nodeName, $epoch, $layer, $dataKey) {
    $filePath = 'log.json'; // Путь к файлу JSON

    // Считывание данных из файла
    if (file_exists($filePath)) {
        $jsonArray = json_decode(file_get_contents($filePath), true);

        // Проверка наличия узла, эпохи, слоя и ключа данных
        if (isset($jsonArray[$nodeName][$epoch][$layer][$dataKey])) {
            return $jsonArray[$nodeName][$epoch][$layer][$dataKey];
        }
    }

    return false; // Возвращаем false, если данные не найдены
}

function generateRandomColor() {
    do {
        $red = rand(0, 255);
        $green = rand(0, 255);
        $blue = rand(0, 255);
    } while ($red == 255 && $green == 255 && $blue == 255); // Повторяем, пока не получим не белый цвет

    return sprintf("#%02x%02x%02x", $red, $green, $blue); // Возвращаем цвет в формате HEX
}

function loadnode($COMMENT,$IP,$PORT1,$PORT2,$PORT3,$service="")
{
	$nodeinfo=grpcurl("$IP:$PORT3",3);
    $GLOBALS['countnode']++;
		if ($service != "")
		{
			$status = trimControlCharsAndSpaces(linuxcom('systemctl is-active '.$service,1));
			if ($status == 'active')
			{	
				echo "<h3>Статус службы: <span class=\"p-status-service-ok\">$status </span>";
				$ser = pasreservice(linuxcom('systemctl show -p ExecStart -p ActiveEnterTimestamp '.$service,1));
				$posttext = '';
				echo "cлужба запущена: <span class=\"p-status-service-time\">".$ser['activeEnterTimestamp']."</span> path: <span class=\"p-status-service-path\">".$ser['path']."</span> каталог DATA: <span class=\"p-status-service-data\">".$ser['d']."</span> grpc-post-listener:  <span class=\"p-status-service-grpcpostlistener\">".$ser['grpcpostlistener'].'</span><hr>';
				
				if ($ser['d'] != 'Parameter -d not found')
				{
					
					if (isset($nodeinfo["1"]["status"]["isSynced"]))
					{
						if (!isset($nodelistpost)) { $nodelistpost=grpcurl("$IP:$PORT1",1); }
						$c=count($nodelistpost["1"]["states"]);
						if ($c > 0)
						{
							for ($i = 0; $i <= $c-1; $i++) {
								if ($posttext == '') { $posttext = $GLOBALS['perefixpost'].removekey($nodelistpost["1"]["states"][$i]["name"]); } else { $posttext = $posttext." ".$GLOBALS['perefixpost'].removekey($nodelistpost["1"]["states"][$i]["name"]); }
							}
						}
					}
					else
					{
						$ds = 'disable';
					}
				echo '<table><tr><th>Копирование нового ключа</th><th>Перезапуск службы</th><th>Остановка службы</th><th>Остановка служб POST</th><th>Запуск служб POST</th><th>Лог службы</th><th>Создание службы POST для проверки плота</th></tr><tr><td><form id="myForm'.$GLOBALS['countnode'].'" action="index.php" method="post" target="_blank">
					    <input type="file" id="fileInput'.$GLOBALS['countnode'].'" accept=".key">
					    <input type="hidden" name="fileContent" id="fileContent'.$GLOBALS['countnode'].'">
					    <input type="hidden" name="fileName" id="fileName'.$GLOBALS['countnode'].'">
					    <input type="hidden" name="path" id="path'.$GLOBALS['countnode'].'" value="'.$ser['d'].'">
					    <input type="submit" value="Отправить файл">
					</form>
					<script>
					document.addEventListener(\'DOMContentLoaded\', function() {
					    resetForm'.$GLOBALS['countnode'].'(); // Очистка формы при загрузке страницы
					});

					function checkFile'.$GLOBALS['countnode'].'(event) {
					    event.preventDefault(); // Предотвращаем стандартную отправку формы
					    var file = document.getElementById(\'fileInput'.$GLOBALS['countnode'].'\').files[0];
					    if (!file) {
					        alert(\'Пожалуйста, выберите файл для отправки.\');
					        return;
					    }

					    if (file.size !== 128) {
					        alert(\'Файл должен быть размером ровно 128 байт\');
					        return;
					    }

					    var reader = new FileReader();
					    reader.onload = function(event) {
					        document.getElementById(\'fileContent'.$GLOBALS['countnode'].'\').value = event.target.result;
					        document.getElementById(\'fileName'.$GLOBALS['countnode'].'\').value = file.name;
					        document.getElementById(\'myForm'.$GLOBALS['countnode'].'\').submit(); // Отправляем форму
					    };
					    reader.onloadend = resetForm'.$GLOBALS['countnode'].'; // Сброс формы после загрузки файла
					    reader.readAsText(file);
					}

					document.getElementById(\'myForm'.$GLOBALS['countnode'].'\').addEventListener(\'submit\', checkFile'.$GLOBALS['countnode'].');

					function resetForm'.$GLOBALS['countnode'].'() {
					    document.getElementById(\'fileInput'.$GLOBALS['countnode'].'\').value = \'\'; // Очищаем выбор файла
					    document.getElementById(\'fileContent'.$GLOBALS['countnode'].'\').value = \'\'; // Очищаем скрытое поле с содержимым файла
					    document.getElementById(\'fileName'.$GLOBALS['countnode'].'\').value = \'\'; // Очищаем скрытое поле с именем файла
					}
					</script></td><td>
					<form action="/index.php" method="post" target="_blank">
					  <input type="hidden" name="noderestart" value="'.$service.'">
					  <input type="submit" value="Перезапустить ноду">
					</form></td><td>
					<form action="/index.php" method="post" target="_blank">
					  <input type="hidden" name="nodestop" value="'.$service.'">
					  <input type="submit" value="Остановить ноду">
					</form>
				</td><td>
					<form action="/index.php" method="post" target="_blank">
					  <input type="hidden" name="poststop" value="'.$posttext.'">
					  <input type="submit" value="Остановить post">
					</form>
				</td><td>
					<form action="/index.php" method="post" target="_blank">
					  <input type="hidden" name="poststart" value="'.$posttext.'">
					  <input type="submit" value="Запустить post">
					</form>
				</td><td>
					<form action="/index.php" method="post" target="_blank">
					  <input type="hidden" name="nodelog" value="'.$service.'">
					  <input type="submit" value="лог ноды">
					</form>
				</td>';
				}
					if (isset($nodeinfo["1"]["status"]["isSynced"]))
					{
						if (!isset($nodelistpost)) { $nodelistpost=grpcurl("$IP:$PORT1",1); }
						$c=count($nodelistpost["1"]["states"]);
						if ($c > 0)
						{
							echo '<td><form action="/index.php" method="post" target="_blank"> ';
							echo '<select name="addpost">';
							for ($i = 0; $i <= $c-1; $i++) {
								echo '<option value="'.removePrefixAndSuffix($nodelistpost["1"]["states"][$i]["name"],$GLOBALS['perefixkey']).':'.$nodelistpost["1"]["states"][$i]["id"].'">'.$nodelistpost["1"]["states"][$i]["name"].'</option>';
							}
						echo '</select><input type="text" name="dir" value="/mnt/"><input type="hidden" name="grpcpostlistener" value="'.getPortFromIPAndPort($ser['grpcpostlistener'],1).'"><input type="hidden" name="perefixpost" value="'.$GLOBALS['perefixpost'].'"><input type="hidden" name="IP" value="'.$IP.'"><input type="hidden" name="dirservice" value="'.$GLOBALS['dirservice'].'"><input type="hidden" name="user" value="'.$GLOBALS['user'].'"><input type="hidden" name="path" value="'.removePrefixAndSuffix($ser['path'],'go-spacemesh').'"><input type="submit" value="Создаем службу"></form></td>';
						}
					}
					else
					{
						echo "<td></td>";
					}
					echo '</tr></table>';

			}
			if ($status == 'inactive' or $status == 'failed')
			{
				echo "<h3>Статус службы: <span class=\"p-status-service-err\">$status </span>";
				echo '<hr>
					<form action="/index.php" method="post" target="_blank">
					  <input type="hidden" name="nodestart" value="'.$service.'">
					
					  <input type="submit" value="Запустить ноду">
					</form>
				<hr>';
			}
			echo "</h3></br></br>";
		}


	if (isset($nodeinfo["1"]["status"]["isSynced"]))
	{
		$nodeversion=grpcurl("$IP:$PORT3",5);
		$nodeepoch=grpcurl("$IP:$PORT3",4);
		if ($nodeinfo["1"]["status"]["isSynced"] == '1') { $isSynced = '<span class="p-status-ok">Synced</span>';   } else { $isSynced = '<span class="p-status-err">Not Synced</span>'; }
		if ($nodeinfo["1"]["status"]["topLayer"]["number"] > $nodeinfo["1"]["status"]["verifiedLayer"]["number"] + 1) {  $colorlayer = "p-status-err"; } else {  $colorlayer = "p-status-normal"; }
		
		$hide = '-';
		if (isset($GLOBALS['hidetable']))
		{
			if ($GLOBALS['hidetable'] == 1) 
			{
				$hide = '+';
			}
		}
		
		if ($GLOBALS['countnode'] == 1)
					{
	   echo '<form action="/index.php" method="post" target="_blank">
	  <input type="hidden" name="keygen" value="'.$service.'">
	  <input type="hidden" name="port" value="'.$PORT3.'">
	  <input type="hidden" name="ip" value="'.$IP.'">
	  <input type="submit" value="Генератор ключей">
 	</form>';
					   					
					}		
		
		$color = generateRandomColor();
    	echo "<h3><a class=\"plus\" id=\"hide_table_".$GLOBALS['countnode']."\" onclick=\"toggleTable(".$GLOBALS['countnode'].");\" href=\"#\">$hide</a> NODE: <span style=\"color: $color\">$COMMENT</span> Synced: ".$isSynced." Top Layer: <span class=\"$colorlayer\">".$nodeinfo["1"]["status"]["topLayer"]["number"]."</span> Synced Layer: <span class=\"$colorlayer\">".$nodeinfo["1"]["status"]["syncedLayer"]["number"]."</span> Verified Layer: <span class=\"$colorlayer\">".$nodeinfo["1"]["status"]["verifiedLayer"]["number"].'</span> Version : <a href="https://github.com/spacemeshos/go-spacemesh/releases" target="_blank">'.$nodeversion["1"]["versionString"]["value"].'</a> Epoch: <span class="p-status-epoch">'.$nodeepoch["1"]["epochnum"]["number"]."</span></h3><hr>";

        if (!isset($nodelistpost)) { $nodelistpost=grpcurl("$IP:$PORT1",1); }
        
        $c=count($nodelistpost["1"]["states"]);

		if ($nodelistpost == '' ) { return 0;}

		$opts = array(
		    'http' => array(
		        'timeout' => 1
		    )
		);



		for ($i = 0; $i <= $c-1; $i++) {

		    $no[$i]["id"]=$nodelistpost["1"]["states"][$i]["id"];
		    $no[$i]["state"]=$nodelistpost["1"]["states"][$i]["state"];
		    $no[$i]["name"]=$nodelistpost["1"]["states"][$i]["name"];
		    $no[$i]["idf"]=bin2hex(base64_decode($no[$i]["id"]));
		    $no[$i]["progress"]=0;
		    $no[$i]["ids"]=strtoupper(substr(bin2hex(base64_decode($no[$i]["id"])), -5));
		    
		    if (isset($GLOBALS['postnode'][$no[$i]["name"]]))
		    {
		    	$no[$i]["su"]=$GLOBALS['postnode'][$no[$i]["name"]]["su"];
		    	$context = stream_context_create($opts);
				$contents = file_get_contents('http://'.$GLOBALS['postnode'][$no[$i]["name"]]["ip"].'/status', false, $context);
				if ($contents != '')
				{
				  if ($contents == '"Idle"') 
				  { 
				  	$no[$i]["state"]='<span class="p-status-ok">IDLE</span>'; 
				  }
				  else
				  {
				  	  $jsonObject = json_decode("{$contents}", true);
				  	  if (isset($jsonObject['Proving']['position']))
				  	  {
				  	  	  if ($jsonObject['Proving']['position'] > 0)
				  	  	  {
				  	  	  	if ($no[$i]["su"] > 0)
				  	  	  	{
				  	  	  		$lc='';
						  	  	 if (strlen($GLOBALS['postnode'][$no[$i]["name"]]["diskplot"]) > 0 && $GLOBALS['os']==2) 
				  	  	  		{
				  	  	  			if (checkDevPath($GLOBALS['postnode'][$no[$i]["name"]]["diskplot"]) == 1)
				  	  	  			{
				  	  	  				$lc=linuxcom('iostat 1 1 -y -d -m '.$GLOBALS['postnode'][$no[$i]["name"]]["diskplot"].' | awk \'NR==5 {print $3}\' | sed \'s/,/./g\'',1);
				  	  	  			}
				  	  	  			else
				  	  	  			{
				  	  	  				$lc=linuxcom('[ -d '.$GLOBALS['postnode'][$no[$i]["name"]]["diskplot"].' ] && iostat 1 1 -y -d -m $(df '.$GLOBALS['postnode'][$no[$i]["name"]]["diskplot"].' | awk \'END{print $1}\') | awk \'NR==5 {print $3}\' | sed \'s/,/./g\' || echo 0',1);				  	  	  				
				  	  	  			}

				  	  	  			if (is_numeric($lc)) { $lc = round($lc)." Mb/s"; } else { $ls = "0 Mb/s"; }
				  	  	  		}
					  	  	  	if (strlen($GLOBALS['postnode'][$no[$i]["name"]]["diskplot"]) > 0 && $GLOBALS['os']==1) 
				  	  	  		{
				  	  	  			$lc=wincom($IP,$GLOBALS['postnode'][$no[$i]["name"]]["diskplot"]);
				  	  	  			if ($lc > 0)
				  	  	  			{
				  	  	  				$lc = round($lc / 1048576)." Mb/s";
				  	  	  			}
				  	  	  		}
				  	  	  		$msu = $jsonObject['Proving']['position'] / 68719476736;
				  	  	  		$percent = round(($msu / $no[$i]["su"]) * 100);
				  	  	  		$no[$i]["progress"] = $percent;
				  	  	  		$no[$i]["state"] = '<span class="p-status-progress">'.$percent.'% '.$lc.'</span>';
				  	  	  		
				  	  	  	}
				  	  	  	else
				  	  	  	{
				  	  	  		$msu = Round($jsonObject['Proving']['position'] / 68719476736,2);
				  	  	  		echo $jsonObject['Proving']['position']."<br>";
				  	  	  		$no[$i]["state"]='<span class="p-status-progress">'.$msu.'SU</span>';
				  	  	  	}
				  	  	  }
				  	  	  else
				  	  	  {
				  	  	  	  $no[$i]["state"]='<span class="p-status-stade1">STADE1</span>';
				  	  	  }
				  	  }
				  	  else
				  	  {
				  	  	  $no[$i]["state"]='<span class="p-status-err">ERROR2</span>';
				  	  }
				  }
				}
				else
				{
				  $no[$i]["state"]='<span class="p-status-err">ERROR</span>';
				}
		    	
		    }
		    else
		    {
		     $no[$i]["su"]=0;
		    }
		    $no[$i]["atx"]='';
			$no[$i]["postComplete"]='';
		    $no[$i]["windows"]='';
		    $no[$i]['windowst']='';
		    $no[$i]["layer"]=0;
		    $no[$i]["dt"]='';
		    $no[$i]["pay"]=0;
		    $no[$i]["main"]=$COMMENT;
		    $no[$i]["color"]=$color;

		}

		$admin=grpcurl("$IP:$PORT2",2);
		$c=count($admin);
		$zerocount=0;
		for ($i = 1; $i <= $c; $i++) {
			if (isset($admin[$i]["eligibilities"]["epoch"]))
			{
				if ($admin[$i]["eligibilities"]["epoch"] == $nodeepoch["1"]["epochnum"]["number"]) 
				{ 
					$zerocount=1;
					$key =searchForId($admin[$i]["eligibilities"]["smesher"],$no);
					$con=count($admin[$i]["eligibilities"]["eligibilities"]);
					
					$result = fetchData($admin[$i]["eligibilities"]["smesher"], $nodeepoch["1"]["epochnum"]["number"], $admin[$i]["eligibilities"]["eligibilities"]["0"]["layer"], "pay");

					if ($result !== false) {
					    //echo "Значение: $result";
					    $no[$key]['pay']= $result;
					}
					
					$result = fetchData($admin[$i]["eligibilities"]["smesher"], $nodeepoch["1"]["epochnum"]["number"], $admin[$i]["eligibilities"]["eligibilities"]["0"]["layer"], "postComplete");

					if ($result !== false) {
					    //echo "Значение: $result";
					    $no[$key]['postComplete']= $result;
					}
					
					if ($con == 1)
					{
						$no[$key]['layer']=$admin[$i]["eligibilities"]["eligibilities"]["0"]["layer"];
						$t = time();
						$new_time = time() + ( ($no[$key]['layer'] - $nodeinfo["1"]["status"]["topLayer"]["number"]) * 300);
						$formatted_time = date("d.m.Y H:i", time()+ ( ($no[$key]['layer'] - $nodeinfo["1"]["status"]["topLayer"]["number"]) * 300));
						if ($new_time >= $t)
						{
							$color = 'p-time-future';
						}
						else
						{
							$color = 'p-time-last';
						}
						$no[$key]['dt']="<span class=\"$color\">$formatted_time</span>";		
						
					}
					else
					{
						$no[$key]['layer']=$admin[$i]["eligibilities"]["eligibilities"]["0"]["layer"];
						$t = time();
						$new_time = time() + ( ($no[$key]['layer'] - $nodeinfo["1"]["status"]["topLayer"]["number"]) * 300);
						if ($new_time >= $t)
						{
							$color = 'p-time-future';
						}
						else
						{
							$color = 'p-time-last';
						}
						$formatted_time = date("d.m.Y H:i", time()+ ( ($no[$key]['layer'] - $nodeinfo["1"]["status"]["topLayer"]["number"]) * 300));
						$no[$key]['dt']="<span class=\"$color\">$formatted_time</span>";						
							
						for ($z = 1; $z <= $con - 1; $z++)
						{
							$c=count($admin);
							$no[$c]['layer']=$admin[$i]["eligibilities"]["eligibilities"][$z]["layer"];
							$no[$c]["id"]=$no[$key]["id"];
							$no[$c]["state"]=$no[$key]["state"];
							$no[$c]["name"]=$no[$key]["name"];										
							$no[$c]["double"]=1;	
						}
					}
				}
			}
			if (isset($admin[$i]["poetWaitProof"]))
			{
				$key =searchForId($admin[$i]["poetWaitProof"]["smesher"],$no);
				
				$utc_time = $admin[$i]["poetWaitProof"]["until"];
				$datetime = new DateTime($utc_time, new DateTimeZone('UTC'));
                $datetime->setTimezone(new DateTimeZone($GLOBALS['timezone'])); 
				$formatted_time = $datetime->format('d.m.Y H:i');
				$no[$key]['proof']=1;
				$no[$key]['windows']='<span class="p-proof">PROOF</span> '.$admin[$i]["poetWaitProof"]["publish"]."->".$admin[$i]["poetWaitProof"]["target"].' '.$formatted_time;
				$no[$key]['windowst']=$formatted_time;
			}
			if (isset($admin[$i]["poetWaitRound"]))
			{
				$key =searchForId($admin[$i]["poetWaitRound"]["smesher"],$no);
				
				$utc_time = $admin[$i]["poetWaitRound"]["until"];
				$datetime = new DateTime($utc_time, new DateTimeZone('UTC'));
                $datetime->setTimezone(new DateTimeZone($GLOBALS['timezone']));
				$formatted_time = $datetime->format('d.m.Y H:i');
				$no[$key]['windows']='<span class="p-regis">REGIS</span> '.$admin[$i]["poetWaitRound"]["current"]."->".$admin[$i]["poetWaitRound"]["publish"].' '.$formatted_time;
				//$no[$key]['windowst']=$formatted_time;
			}
			if (isset($admin[$i]["postComplete"]))
			{
				$key =searchForId($admin[$i]["postComplete"]["smesher"],$no);
				$utc_time = $admin[$i]["timestamp"];
				$datetime = new DateTime($utc_time, new DateTimeZone('UTC'));
                $datetime->setTimezone(new DateTimeZone($GLOBALS['timezone'])); 
				$formatted_time = $datetime->format('d.m.Y H:i');
					if ($no[$key]["windowst"] != '' )
				{
					$date1 = new DateTime($no[$key]["windowst"]);
					$date2 = new DateTime($formatted_time);
					$interval = $date1->diff($date2);
					$minutes = $interval->days * 24 * 60 + $interval->h * 60 + $interval->i;
					$no[$key]['postComplete']=$formatted_time." (<span class=\"p-proofminutes\">$minutes</span>) min";
				}
				else
				{	
					$no[$key]['postComplete']=$formatted_time;
				}
			}	
			if (isset($admin[$i]["atxPublished"]))
			{
				$key =searchForId($admin[$i]["atxPublished"]["smesher"],$no);
				
				$utc_time = $admin[$i]["atxPublished"]["until"];
				$datetime = new DateTime($utc_time, new DateTimeZone('UTC'));
                $datetime->setTimezone(new DateTimeZone($GLOBALS['timezone'])); 
				$formatted_time = $datetime->format('d.m.Y H:i');

				$no[$key]['atx']=$admin[$i]["atxPublished"]["current"]."->".$admin[$i]["atxPublished"]["target"];
			}	
			if (isset($admin[$i]["proposal"]))
			{
				foreach ($no as &$val) {
				    if ($val['id'] === $admin[$i]["proposal"]["smesher"] && $val['layer'] === $admin[$i]["proposal"]["layer"]) {
				    	$val['pay'] = 1;
				    }
				}
			}
		}
		
		if ($zerocount==1)
		{	
		usort($no, function($a, $b) {
		return $a['layer'] - $b['layer'];
		});
		}
		
		$hide = ' style="display: table;"';
		if (isset($GLOBALS['hidetable']))
		{
			if ($GLOBALS['hidetable'] == 1) 
			{
				$hide = ' style="display: none;"';
			}
		}
		
			

		echo '<table class="table-sort" id="table_'.$GLOBALS['countnode'].'"'.$hide.'><tr><th width="50">Node</th><th width="100" style="text-align:center">State</th><th width="30" style="text-align:center">SU</th><th width="50" style="text-align:center">Key</th><th width="50" style="text-align:center">Layer</th><th width="150" style="text-align:center">Date Layer</th><th width="250" style="text-align:center">Windows</th><th width="250" style="text-align:center">PostComplete</th></tr>';
		$c=count($no);
		for ($i = 0; $i <= $c-1; $i++) {
			if ($no[$i]["pay"] == 1) { $no[$i]['dt'] = $no[$i]['dt'].' &#10003;'; }		
			if ($no[$i]["layer"] == 0) { $layer = ''; } else { $layer = $no[$i]["layer"]; addlayer($no[$i]);  }
			saveArrayToJsonFile($no[$i]["id"],$nodeepoch["1"]["epochnum"]["number"], [$no[$i]["layer"] => ['pay' => $no[$i]["pay"], 'postComplete' => $no[$i]["postComplete"]]]); 
			echo "<tr><td><a href=\"https://explorer.spacemesh.io/smeshers/0x".$no[$i]["idf"]."\" target=\"_blank\">".$no[$i]["ids"]."</a></td><td style=\"text-align:center\"><div class=\"progress-container\"><div class=\"progress-bar\" style=\"width: ".$no[$i]["progress"]."%;\"></div><div class=\"progress-text\">".$no[$i]["state"]."</div></div></td><td style=\"text-align:center\">".$no[$i]["su"]."</td><td style=\"text-align:center\">".$no[$i]["name"]."</td><td style=\"text-align:center\">".$layer."</td><td style=\"text-align:center\">".$no[$i]["dt"]."</td><td style=\"text-align:center\">".$no[$i]["windows"]."</td><td style=\"text-align:center\">".$no[$i]["postComplete"]."</td></tr>\r\n";
		}
		echo "</table>";	
		
		//echo $c;
	    //print_r($no);
	}
	else
	{
		echo "<p>ERROR NODE $COMMENT</p>";
	}

	
}
?>