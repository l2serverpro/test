 <?php
addOrUpdatePostNode("26.key","127.0.0.1:50077","171","/dev/disk/by-uuid/f98a4c86-da0d-48b5-8b6c-ddc57b1f30ff");
checkgrpcurl();	
//Донаты sm1qqqqqqp5v5shd4wzqugw9ztgjx3plwh9ml0vwyq6nts89
//Прописываем сюда твою временную зону найти свою можно тут https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
$timezone = 'Europe/Moscow';
date_default_timezone_set($timezone);

//Скрыты ли таблицы по умолчанию.
$hidetable = 0;

//Управление нодами в линукс.
//PHP вызывает команды через sudo systemctl,sed,tee 
//Для того что PHP не просил пароль sudo, надо добавить в /etc/sudoers строки, либо переключатся на окно с PHP
//ВАШUSER ALL=(ALL) NOPASSWD: /usr/bin/systemctl
//ВАШUSER ALL=(ALL) NOPASSWD: /usr/bin/sed
//ВАШUSER ALL=(ALL) NOPASSWD: /usr/bin/tee
//ВАШUSER ALL=(ALL) NOPASSWD: /usr/sbin/blkid
//Перефикс службы post, для проверки плотов например все службы начинаются на spXXXX где XXXX число номер ноды из ключа 
$perefixpost = 'sp';
//Перефикс ключа, например ключи называются node-XXXX.key где XXXX обязательно цифровое значение, если у вас какой-то другой формат ключей работать не будет
$perefixkey= '';
//Пользователь из под которого стартуют службы
$user = 'stereo';
//Папка где у вас линукс хранит все службы
$dirservice='/usr/lib/systemd/system/';
//

//Добавление сервисов проверки плотов в формате "название файла ключа","IP:PORT","SU размер ноды" если у вас хватило таланта использовать одно и тоже название ключа в разных нодах, вы можете вызвать addOrUpdatePostNode повторно, с новыми данными повторных ключей перед каждым loadnode, для линукс можно указать диск скорость которого будет измерена
addOrUpdatePostNode("1.key","127.0.0.1:50051","27",'/dev/disk/by-uuid/a58b175a-1f77-4e0d-807b-0b9ac17bd6e4');
addOrUpdatePostNode("2.key","127.0.0.1:50052","32",'/dev/disk/by-uuid/f98a4c86-da0d-48b5-8b6c-ddc57b1f30ff');
addOrUpdatePostNode("4.key","127.0.0.1:50053","64",'/dev/disk/by-uuid/e64a3834-a6d9-45ef-8e77-f398a0720761');
addOrUpdatePostNode("5.key","127.0.0.1:50054","152",'/dev/disk/by-uuid/febdc20d-5059-4528-9d5e-a46b690f24b2');
addOrUpdatePostNode("6.key","127.0.0.1:50055","152",'/dev/disk/by-uuid/5782a7a8-aa42-428d-b7e7-8e14cfaf326a');
addOrUpdatePostNode("7.key","127.0.0.1:50056","168",'/dev/disk/by-uuid/6099e09f-091c-428e-9ab7-ee23f17cafe5');
addOrUpdatePostNode("8.key","127.0.0.1:50057","152",'/dev/disk/by-uuid/678dbcc6-fa5f-4b3e-9657-8a825df93a80');
addOrUpdatePostNode("9.key","127.0.0.1:50058","168",'/dev/disk/by-uuid/b348cb8e-20ed-456a-875a-7816bc8cd270');
addOrUpdatePostNode("10.key","127.0.0.1:50059","168",'/dev/disk/by-uuid/24f3318c-1c65-42e2-884a-d13a360c9d11');
addOrUpdatePostNode("11.key","127.0.0.1:50060","168",'/dev/disk/by-uuid/e8f0a333-d7e4-4142-b608-0526e052cb62');
addOrUpdatePostNode("12.key","127.0.0.1:50061","152",'/dev/disk/by-uuid/bbd79acc-2db0-4497-9ea4-cf86c692ca02');
addOrUpdatePostNode("13.key","127.0.0.1:50062","168",'/dev/disk/by-uuid/c7e30479-c368-4cd2-8e8c-ba9f79e17afe');
addOrUpdatePostNode("14.key","127.0.0.1:50063","168",'/dev/disk/by-uuid/7add5869-ce42-4511-84d9-dadf0f879688');
addOrUpdatePostNode("15.key","127.0.0.1:50064","168",'/dev/disk/by-uuid/894b6760-a8ef-4540-be42-64c5baef87c5');
addOrUpdatePostNode("16.key","127.0.0.1:50065","200",'/dev/disk/by-uuid/1d81d70a-6ee0-4d4c-92aa-c2028d7e4253');
addOrUpdatePostNode("17.key","127.0.0.1:50066","200",'/dev/disk/by-uuid/1b3e428a-9ec4-4c39-8528-43f51a3df338');
addOrUpdatePostNode("18.key","127.0.0.1:50067","200",'/dev/disk/by-uuid/96a00b9d-21d7-4dd0-93c7-5af4d579c650');
addOrUpdatePostNode("19.key","127.0.0.1:50068","203",'/dev/disk/by-uuid/a114b4e2-3be5-432b-ae5b-13000a7eb3ec');
addOrUpdatePostNode("20.key","127.0.0.1:50069","203",'/dev/disk/by-uuid/df9eb7a3-22ce-49ae-8de0-90735260fa68');
addOrUpdatePostNode("21.key","127.0.0.1:50070","205",'/dev/disk/by-uuid/a58b175a-1f77-4e0d-807b-0b9ac17bd6e4');
addOrUpdatePostNode("22.key","127.0.0.1:50071","255",'/dev/disk/by-uuid/678dbcc6-fa5f-4b3e-9657-8a825df93a80');
addOrUpdatePostNode("23.key","127.0.0.1:50072","239",'/dev/disk/by-uuid/e8f0a333-d7e4-4142-b608-0526e052cb62');
addOrUpdatePostNode("25.key","127.0.0.1:50075","239",'/dev/disk/by-uuid/b348cb8e-20ed-456a-875a-7816bc8cd270');
addOrUpdatePostNode("24.key","127.0.0.1:50074","187",'/dev/disk/by-uuid/febdc20d-5059-4528-9d5e-a46b690f24b2');
addOrUpdatePostNode("27.key","127.0.0.1:50076","68",'/dev/disk/by-uuid/febdc20d-5059-4528-9d5e-a46b690f24b2');

//Измерение скорости чтения диска требует пакет iostat
//Вы можете удаленно запросить скорость диска, установите пакет sshpass, если ноды имеют разные IP и пароли меняйте $ssh перед каждым вызовом loadnode. Если нода локальная ssh устанавливать не надо
//$ssh='sshpass -p PASSWORD ssh LOGIN@IP'

//Проверка нод, в формате "КОММЕНТАРИЙ","IP","grpc-post-listener","grpc-private-listener","grpc-public-listener","имя службы ноды для линукс"
loadnode('S1',"127.0.0.1","9093","9095","9094",'s1');
loadnode('S2',"127.0.0.1","9086","9119","9118",'s2');
loadnode('S3',"127.0.0.1","9083","9128","9127",'s3');	
?>