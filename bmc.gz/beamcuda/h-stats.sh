#!/usr/bin/env bash

#######################
# Functions
#######################

get_json_stats(){
  STATS=/var/log/miner/beamcuda/stats.json
  now=$(date +%s)
  upd=$(stat -c %Y $STATS 2>/dev/null)
  local temp=$(jq '.temp' <<< $gpu_stats)
  local fan=$(jq '.fan' <<< $gpu_stats)

  temp=$(jq -rc ".$nvidia_indexes_array" <<< $temp)
  fan=$(jq -rc ".$nvidia_indexes_array" <<< $fan)
  if (( $? == 0 && upd + 180 > now )); then
    readarray -t arr < <(jq -rc '.ver, .avg, .hr, .ac, .rj, .uptime, .gpu' $STATS)
    ver=${arr[0]}
    avg=${arr[1]}
    hs=${arr[2]}
    ac=${arr[3]}
    rj=${arr[4]}
    uptime=${arr[5]}
    hash_arr="${arr[6]}"
    khs=$( echo "$avg" | awk '{ printf $1/1000}')
    #khs=$( echo "$hs" | awk '{ printf $1/1000}')
  else
    hash_arr="[0]"
    khs=0
    ac=0
    rj=0
    ver="$CUSTOM_VERSION"
    uptime=0
    echo "No stats json"
  fi

  stats=$(jq -n --arg ac "$ac" --arg rj "$rj" --arg algo "$algo" --argjson hs "$hash_arr" --arg uptime "$uptime" --arg ver "$ver" \
		--argjson temp "`echo ${temp[@]} | tr " " "\n" | jq -cs '.'`" \
        --argjson fan "`echo ${fan[@]} | tr " " "\n" | jq -cs '.'`" \
    '{hs_units: "hs", $hs, $algo, $ver, $uptime, $temp, $fan, ar:[$ac|tonumber,$rj|tonumber]}')
}

#######################
# MAIN script body
#######################

local algo="cryptonight"

stats=""
khs=0

get_json_stats
