#!/usr/bin/env bash

function miner_ver() {
	local MINER_VER=$BEAMCUDA_VER
	[[ -z $MINER_VER ]] && MINER_VER=$MINER_LATEST_VER
	echo $MINER_VER
}


function miner_config_echo() {
	local MINER_VER=`miner_ver`
	miner_echo_config_file "/hive/miners/$MINER_NAME/$MINER_VER/beamcuda.conf"
}

function miner_config_gen() {

	local MINER_CONFIG="$MINER_DIR/$MINER_VER/beamcuda.conf"

	conf=""
	conf+="WORKER=\"$BEAMCUDA_TEMPLATE\""$'\n'
	conf+="PORT=\"$BEAMCUDA_URL\""$'\n'
	conf+="EXTRA=\"$BEAMCUDA_USER_CONFIG\""$'\n'

	echo "$conf" > $MINER_CONFIG
}
