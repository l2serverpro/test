#!/usr/bin/env bash

export GPU_MAX_HEAP_SIZE=100
export GPU_MAX_USE_SYNC_OBJECTS=1
export GPU_SINGLE_ALLOC_PERCENT=100
export GPU_MAX_ALLOC_PERCENT=100
export GPU_MAX_SINGLE_ALLOC_PERCENT=100
export GPU_ENABLE_LARGE_ALLOCATION=100
export GPU_MAX_WORKGROUP_SIZE=1024


. h-manifest.conf
[ ! -d "/var/log/miner/custom/grminer/" ] && mkdir -p /var/log/miner/custom/grminer
conf=`cat $MINER_CONFIG_FILENAME`
cd /hive/miners/custom/grminer/1.8.0

eval "./grminer -w ${conf} 2>&1 | tee --append $CUSTOM_LOG_BASENAME.log"
