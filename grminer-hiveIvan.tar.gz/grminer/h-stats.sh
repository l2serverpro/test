#!/usr/bin/env bash

#######################
# Functions
#######################

get_json_stats(){
  STATS=/var/log/miner/custom/grminer/stats.json
  now=$(date +%s)
  upd=$(stat -c %Y $STATS 2>/dev/null)
  if (( $? == 0 && upd + 180 > now )); then
    readarray -t arr < <(jq -rc '.ver, .avg/1000, .hr, .ac, .rj, .uptime, .gpu, .bus_numbers' $STATS)
    ver=${arr[0]}
    khs=${arr[1]}
    hs=${arr[2]}
    ac=${arr[3]}
    rj=${arr[4]}
    uptime=${arr[5]}
    hash_arr="${arr[6]}"
    bus_numbers="${arr[7]}"
    #khs=$( echo "$hs" | awk '{ printf $1/1000}')

    readarray -t gpu_stats < <(jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
    busids=(${gpu_stats[0]})
    brands=(${gpu_stats[1]})
    temps=(${gpu_stats[2]})
    fans=(${gpu_stats[3]})
    count=${#busids[@]}

    # match by busid
    readarray -t busid_arr < <(echo "$bus_numbers" | jq -rc '.[]') # 1 2 3
    fan_arr=()
    temp_arr=()
    for(( i=0; i < count; i++ )); do
      [[ "${brands[i]}" != "nvidia" ]] && continue
      [[ ! "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]] && continue
      [[ ! " ${busid_arr[@]} " =~ \ $((16#${BASH_REMATCH[1]}))\  ]] && continue
      temp_arr+=(${temps[i]})
      fan_arr+=(${fans[i]})
    done
  fan=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
  temp=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`

  else
    hash_arr="null"
    bus_numbers="null"
    khs=0
    ac=0
    rj=0
    ver="$CUSTOM_VERSION"
    uptime=0
    temp="null"
    fan="null"
    echo "No stats json"
  fi

  stats=$(jq -n --arg ac "$ac" --arg rj "$rj" --arg algo "$algo" --argjson bus_numbers "$bus_numbers" --argjson hs "$hash_arr" \
          --arg uptime "$uptime" --arg ver "$ver" --argjson temp "$temp" --argjson fan "$fan" \
          '{hs_units: "hs", $hs, $algo, $ver, $uptime, $bus_numbers, $fan, $temp, ar:[$ac|tonumber,$rj|tonumber]}')
}

#######################
# MAIN script body
#######################

stats=""
khs=0

get_json_stats
