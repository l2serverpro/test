#!/usr/bin/env bash

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME

conf=""

conf+="$CUSTOM_TEMPLATE"

#generating config
echo "$conf" > $CUSTOM_CONFIG_FILENAME
